from query_data import qandr

query="what is a nervous system in two sentences?"
response=qandr(query)
print(response)